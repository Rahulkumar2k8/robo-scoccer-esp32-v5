package com.esp32rc.wokwilab;

import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private UsbSerialBridge usbBridge;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = this.bridge.getWebView();
        if (wv != null) {
            usbBridge = new UsbSerialBridge(this, wv);
            wv.addJavascriptInterface(usbBridge, "AndroidUsb");
        }
    }

    @Override
    public void onDestroy() {
        if (usbBridge != null) {
            usbBridge.disconnect();
        }
        super.onDestroy();
    }
}
