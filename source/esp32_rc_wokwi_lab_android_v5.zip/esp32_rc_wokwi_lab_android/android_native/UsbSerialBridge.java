package com.esp32rc.wokwilab;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

public class UsbSerialBridge implements SerialInputOutputManager.Listener {
    private static final String ACTION_USB_PERMISSION = "com.esp32rc.wokwilab.USB_PERMISSION";

    private final Activity activity;
    private final WebView webView;
    private final UsbManager usbManager;
    private UsbSerialPort serialPort;
    private SerialInputOutputManager ioManager;
    private final StringBuilder lineBuffer = new StringBuilder();
    private volatile boolean isFlashing = false;

    public UsbSerialBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.usbManager = (UsbManager) activity.getSystemService(Context.USB_SERVICE);
    }

    private void emitOrgSerial(String line, String kind) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("line", line);
            obj.put("kind", kind);
            final String js = "window.__onOrgSerial && window.__onOrgSerial(" + obj.toString() + ");";
            activity.runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception ignored) {}
    }

    private void emitStatus(boolean connected, String device, String error) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("connected", connected);
            obj.put("device", device != null ? device : "");
            obj.put("error", error != null ? error : "");
            final String js = "window.__onAndroidUsbStatus && window.__onAndroidUsbStatus(" + obj.toString() + ");";
            activity.runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception ignored) {}
    }

    private void emitBadge(String state, String text) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("state", state);
            obj.put("text", text);
            final String js = "window.__onNativeStatus && window.__onNativeStatus(" + obj.toString() + ");";
            activity.runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public String listDevices() {
        JSONArray arr = new JSONArray();
        try {
            List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
            for (UsbSerialDriver d : drivers) {
                UsbDevice dev = d.getDevice();
                JSONObject o = new JSONObject();
                o.put("deviceId", dev.getDeviceId());
                o.put("deviceName", dev.getDeviceName());
                o.put("vendorId", dev.getVendorId());
                o.put("productId", dev.getProductId());
                o.put("driver", d.getClass().getSimpleName().replace("SerialDriver", ""));
                arr.put(o);
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    @JavascriptInterface
    public String connect(int baudRate) {
        if (isFlashing) return "Flash in progress...";
        try {
            disconnect();
            List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
            if (drivers.isEmpty()) {
                return "No ESP32 / USB-UART device found on USB-OTG.";
            }
            UsbSerialDriver driver = drivers.get(0);
            UsbDevice device = driver.getDevice();
            if (!usbManager.hasPermission(device)) {
                int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0;
                PendingIntent pi = PendingIntent.getBroadcast(activity, 0, new Intent(ACTION_USB_PERMISSION), flags);
                usbManager.requestPermission(device, pi);
                return "PERMISSION_REQUESTED";
            }
            UsbDeviceConnection conn = usbManager.openDevice(device);
            if (conn == null) {
                return "Could not open USB-OTG device connection.";
            }
            serialPort = driver.getPorts().get(0);
            serialPort.open(conn);
            serialPort.setParameters(baudRate, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            serialPort.setDTR(true);
            serialPort.setRTS(true);

            ioManager = new SerialInputOutputManager(serialPort, this);
            ioManager.start();

            String label = driver.getClass().getSimpleName().replace("SerialDriver", "");
            emitOrgSerial("--- [ORG USB-OTG] Connected to " + label + " @ " + baudRate + " baud ---", "system");
            emitStatus(true, label, "");
            return "OK";
        } catch (Exception e) {
            emitOrgSerial("[OTG ERR] " + e.getMessage(), "error");
            emitStatus(false, "", e.getMessage());
            return "Error: " + e.getMessage();
        }
    }

    @JavascriptInterface
    public void disconnect() {
        try {
            if (ioManager != null) {
                ioManager.setListener(null);
                ioManager.stop();
                ioManager = null;
            }
            if (serialPort != null) {
                serialPort.close();
                serialPort = null;
                if (!isFlashing) emitOrgSerial("--- [ORG USB-OTG] Disconnected ---", "system");
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public boolean send(String text) {
        try {
            if (serialPort == null || isFlashing) return false;
            byte[] data = (text + "\n").getBytes(StandardCharsets.UTF_8);
            serialPort.write(data, 1000);
            return true;
        } catch (Exception e) {
            emitOrgSerial("[OTG TX ERR] " + e.getMessage(), "error");
            return false;
        }
    }

    // =========================================================================
    // REAL ESP32 ROM BOOTLOADER SLIP FLASHER OVER ANDROID USB-OTG
    // =========================================================================
    private static byte[] slipEncode(byte[] raw) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(raw.length + 16);
        out.write(0xC0);
        for (byte b : raw) {
            int v = b & 0xFF;
            if (v == 0xC0) { out.write(0xDB); out.write(0xDC); }
            else if (v == 0xDB) { out.write(0xDB); out.write(0xDD); }
            else { out.write(v); }
        }
        out.write(0xC0);
        return out.toByteArray();
    }

    private static byte[] buildCommand(int op, byte[] payload, int checksum) {
        ByteBuffer bb = ByteBuffer.allocate(8 + payload.length).order(ByteOrder.LITTLE_ENDIAN);
        bb.put((byte) 0x00);
        bb.put((byte) (op & 0xFF));
        bb.putShort((short) (payload.length & 0xFFFF));
        bb.putInt(checksum);
        bb.put(payload);
        return slipEncode(bb.array());
    }

    private static int espChecksum(byte[] data) {
        int c = 0xEF;
        for (byte b : data) c ^= (b & 0xFF);
        return c & 0xFF;
    }

    private byte[] readSlipFrame(UsbSerialPort port, int timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        byte[] tmp = new byte[256];
        ByteArrayOutputStream frame = new ByteArrayOutputStream();
        boolean inFrame = false;
        boolean escaping = false;

        while (System.currentTimeMillis() < deadline) {
            int n = port.read(tmp, 80);
            if (n <= 0) continue;
            for (int i = 0; i < n; i++) {
                int b = tmp[i] & 0xFF;
                if (b == 0xC0) {
                    if (inFrame && frame.size() >= 8) {
                        return frame.toByteArray();
                    }
                    frame.reset();
                    inFrame = true;
                    escaping = false;
                } else if (inFrame) {
                    if (escaping) {
                        if (b == 0xDC) frame.write(0xC0);
                        else if (b == 0xDD) frame.write(0xDB);
                        escaping = false;
                    } else if (b == 0xDB) {
                        escaping = true;
                    } else {
                        frame.write(b);
                    }
                }
            }
        }
        return null;
    }

    private boolean sendAndAwaitOp(UsbSerialPort port, int op, byte[] payload, int checksum, int timeoutMs) throws Exception {
        byte[] pkt = buildCommand(op, payload, checksum);
        port.write(pkt, 2000);
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            byte[] resp = readSlipFrame(port, (int) Math.max(100, deadline - System.currentTimeMillis()));
            if (resp != null && resp.length >= 8 && (resp[0] & 0xFF) == 0x01 && (resp[1] & 0xFF) == (op & 0xFF)) {
                return true;
            }
        }
        return false;
    }

    @JavascriptInterface
    public String flashBinaryBase64(final String b64Data, final int flashOffset) {
        if (isFlashing) return "Already flashing ESP32...";
        List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (drivers.isEmpty()) {
            return "No ESP32 connected on USB-OTG!";
        }
        final UsbSerialDriver driver = drivers.get(0);
        final UsbDevice device = driver.getDevice();
        if (!usbManager.hasPermission(device)) {
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0;
            PendingIntent pi = PendingIntent.getBroadcast(activity, 0, new Intent(ACTION_USB_PERMISSION), flags);
            usbManager.requestPermission(device, pi);
            return "PERMISSION_REQUESTED";
        }

        final byte[] firmware;
        try {
            firmware = Base64.decode(b64Data, Base64.DEFAULT);
        } catch (Exception e) {
            return "Invalid firmware binary data.";
        }

        isFlashing = true;
        new Thread(() -> {
            UsbSerialPort flashPort = null;
            try {
                disconnect();
                emitBadge("idle", "Syncing ESP32...");
                emitOrgSerial("--- [USB-OTG FLASHER] Starting ESP32 upload (" + firmware.length + " bytes @ 0x" + Integer.toHexString(flashOffset) + ") ---", "system");

                UsbDeviceConnection conn = usbManager.openDevice(device);
                if (conn == null) throw new Exception("Could not open USB-OTG connection.");

                flashPort = driver.getPorts().get(0);
                flashPort.open(conn);
                flashPort.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);

                // Standard ESP32 DTR/RTS auto-reset into ROM bootloader
                flashPort.setDTR(false);
                flashPort.setRTS(true);
                Thread.sleep(120);
                flashPort.setDTR(true);
                flashPort.setRTS(false);
                Thread.sleep(60);
                flashPort.setDTR(false);

                emitOrgSerial("[FLASH] Syncing with ESP32 bootloader (hold BOOT if needed)...", "system");
                byte[] syncPayload = new byte[36];
                syncPayload[0] = 0x07; syncPayload[1] = 0x07; syncPayload[2] = 0x12; syncPayload[3] = 0x20;
                Arrays.fill(syncPayload, 4, 36, (byte) 0x55);

                boolean synced = false;
                for (int attempt = 1; attempt <= 14; attempt++) {
                    if (sendAndAwaitOp(flashPort, 0x08, syncPayload, 0, 300)) {
                        synced = true;
                        break;
                    }
                    Thread.sleep(100);
                }
                if (!synced) {
                    throw new Exception("ESP32 bootloader sync failed. Hold the BOOT button on ESP32 and tap Upload USB again.");
                }
                emitOrgSerial("[FLASH] Bootloader synced! Attaching SPI flash...", "system");

                // SPI_ATTACH (0x0D)
                if (!sendAndAwaitOp(flashPort, 0x0D, new byte[8], 0, 1500)) {
                    throw new Exception("SPI_ATTACH command failed.");
                }

                // FLASH_BEGIN (0x02)
                final int BLOCK_SIZE = 1024;
                int numBlocks = (firmware.length + BLOCK_SIZE - 1) / BLOCK_SIZE;
                int eraseSize = numBlocks * BLOCK_SIZE;
                ByteBuffer beginBuf = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
                beginBuf.putInt(eraseSize);
                beginBuf.putInt(numBlocks);
                beginBuf.putInt(BLOCK_SIZE);
                beginBuf.putInt(flashOffset);

                emitOrgSerial("[FLASH] Erasing flash (" + numBlocks + " blocks)...", "system");
                emitBadge("idle", "Erasing...");
                if (!sendAndAwaitOp(flashPort, 0x02, beginBuf.array(), 0, 8000)) {
                    throw new Exception("FLASH_BEGIN erase failed.");
                }

                // FLASH_DATA (0x03)
                int lastPct = -1;
                for (int seq = 0; seq < numBlocks; seq++) {
                    byte[] block = new byte[BLOCK_SIZE];
                    Arrays.fill(block, (byte) 0xFF);
                    int start = seq * BLOCK_SIZE;
                    int copyLen = Math.min(BLOCK_SIZE, firmware.length - start);
                    System.arraycopy(firmware, start, block, 0, copyLen);

                    ByteBuffer dataHdr = ByteBuffer.allocate(16 + BLOCK_SIZE).order(ByteOrder.LITTLE_ENDIAN);
                    dataHdr.putInt(BLOCK_SIZE);
                    dataHdr.putInt(seq);
                    dataHdr.putInt(0);
                    dataHdr.putInt(0);
                    dataHdr.put(block);

                    int csum = espChecksum(block);
                    if (!sendAndAwaitOp(flashPort, 0x03, dataHdr.array(), csum, 2500)) {
                        throw new Exception("FLASH_DATA failed at block " + seq + "/" + numBlocks);
                    }

                    int pct = ((seq + 1) * 100) / numBlocks;
                    if (pct >= lastPct + 10 || seq == numBlocks - 1) {
                        lastPct = pct;
                        emitBadge("idle", "Flash " + pct + "%");
                        emitOrgSerial("[FLASH] Writing firmware... " + pct + "%", "normal");
                    }
                }

                // FLASH_END (0x04) & Hard Reset ESP32 into new firmware
                ByteBuffer endBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
                endBuf.putInt(0); // reboot
                sendAndAwaitOp(flashPort, 0x04, endBuf.array(), 0, 1500);

                flashPort.setDTR(false);
                flashPort.setRTS(true);
                Thread.sleep(100);
                flashPort.setRTS(false);
                flashPort.close();
                flashPort = null;

                emitBadge("ok", "Flashed OK!");
                emitOrgSerial("--- [USB-OTG FLASHER] Upload Complete! ESP32 Rebooted. ---", "system");
            } catch (Exception e) {
                emitBadge("error", "Flash Failed");
                emitOrgSerial("[FLASH ERR] " + e.getMessage(), "error");
            } finally {
                if (flashPort != null) {
                    try { flashPort.close(); } catch (Exception ignored) {}
                }
                isFlashing = false;
            }
        }).start();

        return "STARTED";
    }

    @Override
    public void onNewData(byte[] data) {
        String chunk = new String(data, StandardCharsets.UTF_8);
        synchronized (lineBuffer) {
            lineBuffer.append(chunk);
            int idx;
            while ((idx = lineBuffer.indexOf("\n")) != -1) {
                String line = lineBuffer.substring(0, idx).replace("\r", "");
                lineBuffer.delete(0, idx + 1);
                emitOrgSerial(line, "normal");
            }
        }
    }

    @Override
    public void onRunError(Exception e) {
        emitOrgSerial("[OTG LOST] " + e.getMessage(), "error");
        disconnect();
        emitStatus(false, "", e.getMessage());
    }
}
