import os
import re
import shutil
import subprocess
import tempfile

HTML_PATH = "www/index.html"
OUT_DIR = "www/firmware"
PRESETS = [
    "robosoccer_arcade",
    "robosoccer_pro",
    "rc_car",
    "rc_tank",
    "rc_airplane",
    "rc_ship",
]

os.makedirs(OUT_DIR, exist_ok=True)
html = open(HTML_PATH, "r", encoding="utf-8").read()

for key in PRESETS:
    m = re.search(rf"{key}\s*:\s*\{{.*?code\s*:\s*`(.*?)`\s*\}}", html, re.S)
    if not m:
        print(f"[WARN] Could not extract preset {key}")
        continue
    code = m.group(1).replace("\\\\n", "\\n")
    with tempfile.TemporaryDirectory() as tmp:
        sketch_dir = os.path.join(tmp, key)
        os.makedirs(sketch_dir, exist_ok=True)
        ino_path = os.path.join(sketch_dir, f"{key}.ino")
        with open(ino_path, "w", encoding="utf-8") as f:
            f.write(code)
        print(f"[BUILD] Compiling {key}.ino for esp32:esp32:esp32 ...")
        res = subprocess.run(
            ["arduino-cli", "compile", "--fqbn", "esp32:esp32:esp32", "--export-binaries", sketch_dir],
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            print(res.stdout)
            print(res.stderr)
            raise SystemExit(f"Failed to compile {key}")
        bin_src = os.path.join(sketch_dir, "build", "esp32.esp32.esp32", f"{key}.ino.bin")
        bin_dst = os.path.join(OUT_DIR, f"{key}.bin")
        shutil.copyfile(bin_src, bin_dst)
        print(f"[OK] Exported {bin_dst} ({os.path.getsize(bin_dst)} bytes)")
