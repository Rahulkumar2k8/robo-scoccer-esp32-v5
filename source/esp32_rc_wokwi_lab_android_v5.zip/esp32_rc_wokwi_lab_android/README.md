# ESP32 RC Wokwi Lab — Android APK Project (Capacitor + GitHub Actions)

Builds an installable Android `.apk` containing the full **ESP32 Dev Module + Dual BTS7960 + FlySky FS-i6S** simulator, multi-touch dual gimbals, **RC Channel Mixer** (`CH2 - CH3` / `CH2 + CH3` / `± Diff`), syntax-highlighted Arduino editor, and Dual Serial Monitor.

## Build the `.apk` Automatically on GitHub Actions (No Android Studio Needed)

1. Create a new GitHub repository and upload all files from this folder (make sure `.github/workflows/build-android-apk.yml` is included).
2. Open the **Actions** tab in your GitHub repo and wait ~2 minutes for **Build ESP32 RC Wokwi Lab (Android APK)** to finish.
3. Download **`ESP32_RC_Wokwi_Lab-Android-APK`** from the workflow run artifacts, unzip it, and install `app-debug.apk` on your Android phone.

> **Note:** On Android, the full simulator, multi-touch FS-i6S gimbals, RC Channel Mixer, presets, and **Sim Serial** run directly in the APK. Real `arduino-cli` ESP32 compiling/flashing, Boards Manager, and Library Manager require the Windows desktop Python app (`app.py`), since Android does not natively run the desktop ESP32 GCC toolchain.
